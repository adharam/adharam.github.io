#!/usr/bin/env python3
"""Run HOLE on Structure C/D and compare matched AlphaFold model/seed pairs.

Structures A and B are read from the previous, verified HOLE result set.  The
same HOLE 2.3.1 executable, radii, pore-axis definition and 0.25-A sampling are
used for C and D.  C is paired with A and D with B by AlphaFold prediction
network model number and prediction seed number, never by confidence rank.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
PREVIOUS_ROOT = ROOT.parent / "cav12_hole_analysis"
sys.path.insert(0, str(PREVIOUS_ROOT))
import run_hole_analysis as hole_base  # noqa: E402


INPUT_C = Path("/Users/itoyuto/Downloads/biomolecule/8WE6_1_wo_DCRD")
INPUT_D = Path("/Users/itoyuto/Downloads/biomolecule/8WE6_1_P55042_no_tmp")
AB_RESULTS = PREVIOUS_ROOT / "results"
RESULTS = ROOT / "results"
RUNS = RESULTS / "hole_runs"
PROFILE_GRID = hole_base.PROFILE_GRID
BASE_SEED = 20260906

METRICS = (
    "S6_min_radius_A",
    "gate_radius_A",
    "SF_min_radius_A",
    "SF_landmark_radius_A",
    "pore_min_radius_A",
    "S6_min_z_A",
    "pore_min_z_A",
)
PAIRINGS = (("A", "C", "C_minus_A"), ("B", "D", "D_minus_B"))


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def finite(values: np.ndarray) -> np.ndarray:
    return values[np.isfinite(values)]


def describe(values: np.ndarray) -> dict[str, float | int]:
    values = finite(np.asarray(values, dtype=float))
    if not len(values):
        return {key: math.nan for key in ("n", "mean", "sd", "median", "q05", "q10", "q25", "q75", "q90", "q95", "min", "max")}
    return {
        "n": int(len(values)),
        "mean": float(np.mean(values)),
        "sd": float(np.std(values, ddof=1)) if len(values) > 1 else math.nan,
        "median": float(np.median(values)),
        "q05": float(np.percentile(values, 5)),
        "q10": float(np.percentile(values, 10)),
        "q25": float(np.percentile(values, 25)),
        "q75": float(np.percentile(values, 75)),
        "q90": float(np.percentile(values, 90)),
        "q95": float(np.percentile(values, 95)),
        "min": float(np.min(values)),
        "max": float(np.max(values)),
    }


def tag(row: dict) -> tuple[int, int]:
    return int(row["prediction_model_no"]), int(row["prediction_seed_no"])


def paired_bootstrap_ci(diff: np.ndarray, rng: np.random.Generator, n_boot: int = 20000) -> tuple[float, float]:
    diff = finite(np.asarray(diff, dtype=float))
    indices = rng.integers(0, len(diff), size=(n_boot, len(diff)))
    means = diff[indices].mean(axis=1)
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def load_previous() -> tuple[list[dict], dict[str, dict[tuple[int, int], dict]], dict[str, dict[tuple[int, int], np.ndarray]]]:
    metric_rows = read_csv(AB_RESULTS / "hole_model_metrics.csv")
    by_tag: dict[str, dict[tuple[int, int], dict]] = {"A": {}, "B": {}}
    rank_to_tag: dict[tuple[str, int], tuple[int, int]] = {}
    for row in metric_rows:
        group = row["group"]
        row_tag = tag(row)
        if row_tag in by_tag[group]:
            raise ValueError(f"Duplicate {group} model/seed tag: {row_tag}")
        by_tag[group][row_tag] = row
        rank_to_tag[(group, int(row["rank"]))] = row_tag

    profile_bins: dict[tuple[str, int], dict[float, float]] = {}
    for row in read_csv(AB_RESULTS / "hole_profiles_interpolated.csv"):
        key = (row["group"], int(row["rank"]))
        profile_bins.setdefault(key, {})[round(float(row["z_A"]), 4)] = float(row["radius_A"])
    profiles: dict[str, dict[tuple[int, int], np.ndarray]] = {"A": {}, "B": {}}
    for rank_key, values in profile_bins.items():
        group, _ = rank_key
        row_tag = rank_to_tag[rank_key]
        profiles[group][row_tag] = np.array([values.get(round(float(z), 4), math.nan) for z in PROFILE_GRID])

    expected = {(model, seed) for model in range(1, 6) for seed in range(1, 11)}
    for group in ("A", "B"):
        if set(by_tag[group]) != expected or set(profiles[group]) != expected:
            raise ValueError(f"Previous {group} result does not contain the complete 5 x 10 model/seed design")
    return metric_rows, by_tag, profiles


def make_models(group: str, directory: Path, matching_group: str, previous_by_tag: dict[str, dict[tuple[int, int], dict]]) -> list[hole_base.ModelInfo]:
    models = []
    seen: set[tuple[int, int]] = set()
    for path in hole_base.ranked_files(directory):
        row_tag = hole_base.prediction_tags(path)
        if row_tag in seen:
            raise ValueError(f"Duplicate {group} model/seed tag: {row_tag}")
        seen.add(row_tag)
        # Reuse the corresponding A/B HOLE random seed to minimize numerical
        # path-search noise within each matched comparison.
        matched_seed = int(previous_by_tag[matching_group][row_tag]["hole_seed"])
        models.append(hole_base.ModelInfo(group, hole_base.rank_of(path), path, matched_seed))
    expected = {(model, seed) for model in range(1, 6) for seed in range(1, 11)}
    if seen != expected:
        raise ValueError(f"{group} does not contain the complete 5 x 10 model/seed design")
    return models


def profile_summary(profiles: dict[str, dict[tuple[int, int], np.ndarray]]) -> list[dict]:
    rows = []
    ordered_tags = sorted(next(iter(profiles.values())))
    arrays = {group: np.vstack([profiles[group][row_tag] for row_tag in ordered_tags]) for group in ("A", "B", "C", "D")}
    for i, z in enumerate(PROFILE_GRID):
        row: dict[str, float | int] = {"z_A": float(z)}
        for group in ("A", "B", "C", "D"):
            stats = describe(arrays[group][:, i])
            for name in ("n", "mean", "sd", "q10", "q25", "median", "q75", "q90"):
                row[f"{group}_{name}"] = stats[name]
        rows.append(row)
    return rows


def paired_profile_summary(profiles: dict[str, dict[tuple[int, int], np.ndarray]]) -> list[dict]:
    rows = []
    rng = np.random.default_rng(BASE_SEED + 3)
    for first, second, label in PAIRINGS:
        common = sorted(set(profiles[first]) & set(profiles[second]))
        first_array = np.vstack([profiles[first][row_tag] for row_tag in common])
        second_array = np.vstack([profiles[second][row_tag] for row_tag in common])
        diff = second_array - first_array
        boot_indices = rng.integers(0, len(common), size=(10000, len(common)))
        for i, z in enumerate(PROFILE_GRID):
            values = finite(diff[:, i])
            boot = np.nanmean(diff[boot_indices, i], axis=1)
            rows.append({
                "comparison": f"{first}_vs_{second}",
                "difference": label,
                "z_A": float(z),
                "n_pairs": int(len(values)),
                "mean_difference_A": float(np.mean(values)),
                "sd_difference_A": float(np.std(values, ddof=1)),
                "median_difference_A": float(np.median(values)),
                "q10_difference_A": float(np.percentile(values, 10)),
                "q25_difference_A": float(np.percentile(values, 25)),
                "q75_difference_A": float(np.percentile(values, 75)),
                "q90_difference_A": float(np.percentile(values, 90)),
                "bootstrap_CI95_low_A": float(np.percentile(boot, 2.5)),
                "bootstrap_CI95_high_A": float(np.percentile(boot, 97.5)),
            })
    return rows


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--skip-validation", action="store_true")
    args = parser.parse_args()

    if not hole_base.HOLE.exists():
        raise SystemExit(f"HOLE executable not found: {hole_base.HOLE}")
    RESULTS.mkdir(parents=True, exist_ok=True)
    RUNS.mkdir(parents=True, exist_ok=True)
    hole_base.RESULTS = RESULTS
    hole_base.RUNS = RUNS

    previous_rows, previous_by_tag, previous_profiles = load_previous()
    models = make_models("C", INPUT_C, "A", previous_by_tag) + make_models("D", INPUT_D, "B", previous_by_tag)

    outputs = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(hole_base.run_one, model): model for model in models}
        for future in as_completed(futures):
            outputs.append(future.result())
            model = futures[future]
            print(f"completed {model.group} rank {model.rank:03d}", flush=True)
    outputs.sort(key=lambda item: (item["model"].group, item["model"].rank))

    cd_metric_rows = [item["metrics"] for item in outputs]
    write_csv(RESULTS / "hole_CD_model_metrics.csv", cd_metric_rows)
    write_csv(RESULTS / "hole_all_model_metrics.csv", previous_rows + cd_metric_rows)

    raw_rows = []
    interpolated_rows = []
    cd_profiles: dict[str, dict[tuple[int, int], np.ndarray]] = {"C": {}, "D": {}}
    for item in outputs:
        group = item["model"].group
        row_tag = hole_base.prediction_tags(item["model"].source)
        cd_profiles[group][row_tag] = item["profile"]
        for row in item["raw"]:
            raw_rows.append({"group": group, "rank": item["model"].rank, **row})
        for z, radius in zip(PROFILE_GRID, item["profile"]):
            interpolated_rows.append({
                "group": group,
                "rank": item["model"].rank,
                "prediction_model_no": row_tag[0],
                "prediction_seed_no": row_tag[1],
                "z_A": float(z),
                "radius_A": float(radius),
            })
    write_csv(RESULTS / "hole_CD_profiles_raw.csv", raw_rows)
    write_csv(RESULTS / "hole_CD_profiles_interpolated.csv", interpolated_rows)

    all_profiles = {**previous_profiles, **cd_profiles}
    write_csv(RESULTS / "hole_all_profile_summary.csv", profile_summary(all_profiles))
    write_csv(RESULTS / "hole_paired_profile_comparisons.csv", paired_profile_summary(all_profiles))

    all_rows = previous_rows + cd_metric_rows
    rows_by_group_tag: dict[str, dict[tuple[int, int], dict]] = {group: {} for group in "ABCD"}
    for row in all_rows:
        rows_by_group_tag[row["group"]][tag(row)] = row

    summary_rows = []
    by_network_rows = []
    for metric in METRICS:
        for group in "ABCD":
            values = np.array([float(row[metric]) for row in rows_by_group_tag[group].values()])
            summary_rows.append({"metric": metric, "group": group, **describe(values)})
            for network in range(1, 6):
                subset = np.array([
                    float(row[metric]) for row_tag, row in rows_by_group_tag[group].items()
                    if row_tag[0] == network
                ])
                by_network_rows.append({
                    "metric": metric,
                    "group": group,
                    "prediction_model_no": network,
                    **describe(subset),
                })
    write_csv(RESULTS / "hole_all_metric_summaries.csv", summary_rows)
    write_csv(RESULTS / "hole_all_by_prediction_model.csv", by_network_rows)

    rng = np.random.default_rng(BASE_SEED + 4)
    paired_rows = []
    per_pair_rows = []
    paired_by_network_rows = []
    for first, second, label in PAIRINGS:
        common = sorted(set(rows_by_group_tag[first]) & set(rows_by_group_tag[second]))
        if len(common) != 50:
            raise ValueError(f"Expected 50 matched pairs for {first}-{second}; found {len(common)}")
        for metric in METRICS:
            a = np.array([float(rows_by_group_tag[first][row_tag][metric]) for row_tag in common])
            b = np.array([float(rows_by_group_tag[second][row_tag][metric]) for row_tag in common])
            diff = b - a
            low, high = paired_bootstrap_ci(diff, rng)
            diff_sd = float(np.std(diff, ddof=1))
            correlation = float(np.corrcoef(a, b)[0, 1]) if np.std(a) > 0 and np.std(b) > 0 else math.nan
            paired_rows.append({
                "comparison": f"{first}_vs_{second}",
                "difference": label,
                "metric": metric,
                "n_pairs": len(common),
                "first_group": first,
                "second_group": second,
                "first_mean": float(np.mean(a)),
                "first_sd": float(np.std(a, ddof=1)),
                "first_median": float(np.median(a)),
                "second_mean": float(np.mean(b)),
                "second_sd": float(np.std(b, ddof=1)),
                "second_median": float(np.median(b)),
                "paired_mean_difference": float(np.mean(diff)),
                "paired_median_difference": float(np.median(diff)),
                "paired_difference_sd": diff_sd,
                "percent_change_vs_first_mean": float(100.0 * np.mean(diff) / np.mean(a)) if np.mean(a) else math.nan,
                "paired_bootstrap_CI95_low": low,
                "paired_bootstrap_CI95_high": high,
                "cohen_dz": float(np.mean(diff) / diff_sd) if diff_sd else math.nan,
                "paired_correlation": correlation,
                "n_second_wider": int(np.sum(diff > 0)),
                "n_equal": int(np.sum(np.isclose(diff, 0.0, atol=1e-12))),
                "n_second_narrower": int(np.sum(diff < 0)),
            })
            for row_tag, av, bv, dv in zip(common, a, b, diff):
                per_pair_rows.append({
                    "comparison": f"{first}_vs_{second}",
                    "metric": metric,
                    "prediction_model_no": row_tag[0],
                    "prediction_seed_no": row_tag[1],
                    "first_group": first,
                    "second_group": second,
                    "first_value": float(av),
                    "second_value": float(bv),
                    "paired_difference": float(dv),
                })
            for network in range(1, 6):
                mask = np.array([row_tag[0] == network for row_tag in common])
                paired_by_network_rows.append({
                    "comparison": f"{first}_vs_{second}",
                    "difference": label,
                    "metric": metric,
                    "prediction_model_no": network,
                    **{f"difference_{key}": value for key, value in describe(diff[mask]).items()},
                })
    write_csv(RESULTS / "hole_paired_metric_comparisons.csv", paired_rows)
    write_csv(RESULTS / "hole_paired_model_seed_values.csv", per_pair_rows)
    write_csv(RESULTS / "hole_paired_by_prediction_model.csv", paired_by_network_rows)

    validation_rows = []
    if not args.skip_validation:
        chosen = [model for model in models if model.rank in (1, 10, 20, 30, 40, 50)]
        primary = {(item["model"].group, item["model"].rank): item for item in outputs}
        for model in chosen:
            repeat = hole_base.run_one(model, alternate_seed=model.seed + 100000)
            first = primary[(model.group, model.rank)]
            profile_diff = repeat["profile"] - first["profile"]
            validation_rows.append({
                "group": model.group,
                "rank": model.rank,
                "prediction_model_no": hole_base.prediction_tags(model.source)[0],
                "prediction_seed_no": hole_base.prediction_tags(model.source)[1],
                "seed_primary": model.seed,
                "seed_repeat": model.seed + 100000,
                "S6_min_radius_abs_diff_A": abs(repeat["metrics"]["S6_min_radius_A"] - first["metrics"]["S6_min_radius_A"]),
                "gate_radius_abs_diff_A": abs(repeat["metrics"]["gate_radius_A"] - first["metrics"]["gate_radius_A"]),
                "profile_RMS_diff_A": float(np.sqrt(np.nanmean(profile_diff ** 2))),
                "profile_max_abs_diff_A": float(np.nanmax(np.abs(profile_diff))),
            })
        write_csv(RESULTS / "hole_CD_seed_reproducibility.csv", validation_rows)

    manifest = {
        "method": "HOLE spherical-probe Monte Carlo path finding",
        "hole_version": "2.3.1",
        "hole_executable": str(hole_base.HOLE),
        "hole_source_commit": subprocess.run(
            ["git", "-C", str(PREVIOUS_ROOT / "vendor/hole2"), "rev-parse", "HEAD"],
            text=True,
            stdout=subprocess.PIPE,
            check=True,
        ).stdout.strip(),
        "radius_file": str(hole_base.RADIUS_FILE),
        "radius_file_sha256": hashlib.sha256(hole_base.RADIUS_FILE.read_bytes()).hexdigest(),
        "parameters": {
            "SAMPLE_A": hole_base.SAMPLE_A,
            "ENDRAD_A": hole_base.END_RADIUS_A,
            "MCSTEP": 1000,
            "MCDISP_A": 0.10,
            "MCKT_A": 0.10,
            "HOLE_seed_matching": "C reuses matched A seed; D reuses matched B seed",
        },
        "analysis_frame": {
            "z_zero": "centroid of S6 gate C-alpha atoms",
            "positive_z": "toward selectivity-filter glutamate oxygen centroid",
            "CPOINT": "45% from S6 gate centroid toward SF oxygen centroid",
        },
        "residue_definitions": {
            "S6_gate": hole_base.S6_GATE_RESIDUES,
            "selectivity_filter_glutamates": hole_base.SF_GLU_RESIDUES,
        },
        "comparisons": {
            "A_vs_C": "DCRD present vs DCRD absent; AF2-ptm",
            "B_vs_D": "templates present vs no-template; AF-Multimer v3 with Rad",
            "pairing": "prediction-network model number plus prediction seed number",
        },
        "inputs": {
            "C": [str(path) for path in hole_base.ranked_files(INPUT_C)],
            "D": [str(path) for path in hole_base.ranked_files(INPUT_D)],
            "A_B_previous_results": str(AB_RESULTS),
        },
        "n_models": {group: 50 for group in "ABCD"},
        "validation_reruns_CD": len(validation_rows),
    }
    (RESULTS / "hole_AC_BD_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    print(f"Wrote matched HOLE analysis to {RESULTS}")


if __name__ == "__main__":
    main()
