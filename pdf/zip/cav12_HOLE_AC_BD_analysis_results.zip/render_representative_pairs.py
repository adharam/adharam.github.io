#!/usr/bin/env python3
"""Render representative HOLE pathways with PyMOL."""

import csv
from pathlib import Path

from pymol import cmd


ROOT = Path.cwd() / "cav12_hole_AC_BD_analysis"
RESULTS = ROOT / "results"
PORE_RANGES = "340-420+680-755+1090-1175+1420-1505"
GATE = "400+748+1161+1499"
SF = "363+706+1115+1444"

rows = list(csv.DictReader((RESULTS / "hole_matched_representatives.csv").open()))
for row in rows:
    group = row["group"]
    cmd.reinitialize()
    cmd.load(row["pdb"], "cav12")
    cmd.load(row["sph"], "hole", format="pdb")
    cmd.hide("everything", "all")
    cmd.select("pore_domain", f"cav12 and chain A and resi {PORE_RANGES}")
    cmd.show("cartoon", "pore_domain")
    cmd.color("gray70", "pore_domain")
    cmd.set("cartoon_transparency", 0.20, "pore_domain")
    cmd.select("s6_gate", f"cav12 and chain A and resi {GATE}")
    cmd.select("selectivity_filter", f"cav12 and chain A and resi {SF}")
    cmd.show("sticks", "s6_gate or selectivity_filter")
    cmd.set("stick_radius", 0.18)
    cmd.color("magenta", "s6_gate")
    cmd.color("cyan", "selectivity_filter")
    cmd.alter("hole", "vdw=b")
    cmd.show("spheres", "hole and b < 5.0")
    cmd.color("red", "hole and b < 1.15")
    cmd.color("tv_green", "hole and b > 1.149 and b < 2.30")
    cmd.color("marine", "hole and b > 2.299")
    cmd.set("sphere_transparency", 0.04, "hole")
    cmd.set("orthoscopic", 1)
    cmd.set("depth_cue", 0)
    cmd.set("ray_shadows", 0)
    cmd.set("antialias", 2)
    cmd.set("opaque_background", 1)
    cmd.bg_color("white")
    cmd.reset()
    cmd.turn("x", 90)
    cmd.zoom("pore_domain or (hole and b < 5.0)", buffer=5, complete=1)
    cmd.ray(800, 1080)
    cmd.png(str(RESULTS / f"path_view_matched_{group}.png"), dpi=300)

cmd.quit()
