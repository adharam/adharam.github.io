#!/usr/bin/env python3
"""Prepare core-aligned, model/seed-matched representative HOLE pathways."""

from __future__ import annotations

import csv
import sys
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
PREVIOUS_ROOT = ROOT.parent / "cav12_hole_analysis"
sys.path.insert(0, str(PREVIOUS_ROOT))
import run_hole_analysis as base  # noqa: E402


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    metrics = read_csv(RESULTS / "hole_all_model_metrics.csv")
    metric_lookup = {
        (row["group"], int(row["prediction_model_no"]), int(row["prediction_seed_no"])): row
        for row in metrics
    }
    paired = read_csv(RESULTS / "hole_paired_model_seed_values.csv")
    chosen: dict[str, tuple[int, int]] = {}
    for comparison in ("A_vs_C", "B_vs_D"):
        rows = [
            row for row in paired
            if row["comparison"] == comparison and row["metric"] == "S6_min_radius_A"
        ]
        median = float(np.median([float(row["paired_difference"]) for row in rows]))
        selected = min(rows, key=lambda row: abs(float(row["paired_difference"]) - median))
        chosen[comparison] = (int(selected["prediction_model_no"]), int(selected["prediction_seed_no"]))

    reference_row = min((row for row in metrics if row["group"] == "A"), key=lambda row: int(row["rank"]))
    _, reference_coords = base.read_chain_a(Path(reference_row["source_file"]))
    reference_core = np.vstack([reference_coords[(residue, "CA")] for residue in base.CORE_RESIDUES])

    output_rows = []
    for comparison, groups in (("A_vs_C", ("A", "C")), ("B_vs_D", ("B", "D"))):
        model_no, seed_no = chosen[comparison]
        for group in groups:
            row = metric_lookup[(group, model_no, seed_no)]
            source = Path(row["source_file"])
            lines, coords = base.read_chain_a(source)
            moving_core = np.vstack([coords[(residue, "CA")] for residue in base.CORE_RESIDUES])
            aligned = base.aligned_coordinates(lines, moving_core, reference_core)
            label = f"{comparison}_{group}_model{model_no}_seed{seed_no}"
            pdb_out = RESULTS / f"representative_{label}_aligned.pdb"
            pdb_out.write_text("\n".join(aligned) + "\nTER\nEND\n")

            rank = int(row["rank"])
            run_root = PREVIOUS_ROOT / "results" / "hole_runs" if group in "AB" else RESULTS / "hole_runs"
            sph_in = run_root / f"{group}_rank{rank:03d}" / f"{group}_rank{rank:03d}.sph"
            sph_out = RESULTS / f"representative_{label}_aligned.sph"
            lm = base.landmarks(coords)
            base.transform_sph(
                sph_in,
                sph_out,
                moving_core,
                reference_core,
                gate=lm["gate"],
                axis=lm["axis"],
                z_window=(-4.0, 24.0),
            )
            output_rows.append({
                "comparison": comparison,
                "group": group,
                "prediction_model_no": model_no,
                "prediction_seed_no": seed_no,
                "rank": rank,
                "S6_min_radius_A": row["S6_min_radius_A"],
                "gate_radius_A": row["gate_radius_A"],
                "pdb": str(pdb_out),
                "sph": str(sph_out),
            })
    write_csv(RESULTS / "hole_matched_representatives.csv", output_rows)


if __name__ == "__main__":
    main()
