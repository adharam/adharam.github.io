#!/usr/bin/env python3
"""Assemble four PyMOL panels into one matched representative figure."""

import csv
from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
FONT = Path("/System/Library/Fonts/Supplemental/Arial.ttf")
FONT_BOLD = Path("/System/Library/Fonts/Supplemental/Arial Bold.ttf")
BLACK = (30, 30, 30)
MID = (90, 90, 90)


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(FONT_BOLD if bold else FONT), size)


rows = {row["group"]: row for row in csv.DictReader((RESULTS / "hole_matched_representatives.csv").open())}
im = Image.new("RGBA", (2600, 1500), "white")
draw = ImageDraw.Draw(im)
draw.text((100, 55), "Matched representative HOLE pathways in the core-aligned CaV1.2 pore",
          font=font(40, True), fill=BLACK)

specs = [
    ("A", "A", "DCRD present"),
    ("C", "B", "DCRD absent"),
    ("B", "C", "Rad + template"),
    ("D", "D", "Rad + no template"),
]
for index, (group, panel, caption) in enumerate(specs):
    view = Image.open(RESULTS / f"path_view_matched_{group}.png").convert("RGBA")
    view.thumbnail((620, 1030), Image.Resampling.LANCZOS)
    x = 25 + index * 640
    im.alpha_composite(view, (x + (620 - view.width) // 2, 180))
    draw.text((x + 15, 145), panel, font=font(31, True), fill=BLACK, anchor="ls")
    draw.text((x + 58, 145), f"Structure {group}: {caption}", font=font(23, True), fill=BLACK, anchor="ls")
    row = rows[group]
    draw.text((x + 310, 1260),
              f"model {row['prediction_model_no']}, seed {row['prediction_seed_no']}; rank {int(row['rank']):03d}",
              font=font(20), fill=BLACK, anchor="ma")
    draw.text((x + 310, 1292),
              f"S6-window r_min = {float(row['S6_min_radius_A']):.3f} Å; r(z=0) = {float(row['gate_radius_A']):.3f} Å",
              font=font(20), fill=BLACK, anchor="ma")

legend_y = 1380
entries = [
    ((225, 35, 35), "r < 1.15 Å"),
    ((50, 205, 50), "1.15–2.30 Å"),
    ((35, 105, 180), "r > 2.30 Å"),
    ((220, 0, 220), "S6 gate"),
    ((0, 190, 205), "selectivity filter"),
]
x = 170
for color, label in entries:
    draw.ellipse((x, legend_y - 10, x + 20, legend_y + 10), fill=color, outline=BLACK)
    draw.text((x + 30, legend_y), label, font=font(20), fill=BLACK, anchor="lm")
    x += 430
draw.text((1300, 1450),
          "A–C and B–D use the same prediction-network model/seed within each representative pair; representatives track the median S6 paired difference.",
          font=font(19), fill=MID, anchor="ma")
im.convert("RGB").save(RESULTS / "figure_5_HOLE_AC_BD_matched_representative_paths.png", dpi=(300, 300))
