#!/usr/bin/env python3
"""Create matched A-C and B-D HOLE summaries and publication-style figures."""

from __future__ import annotations

import csv
import math
import re
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
AB_RESULTS = ROOT.parent / "cav12_hole_analysis" / "results"
FONT = Path("/System/Library/Fonts/Supplemental/Arial.ttf")
FONT_BOLD = Path("/System/Library/Fonts/Supplemental/Arial Bold.ttf")

COLORS = {
    "A": (47, 85, 151),
    "B": (217, 95, 2),
    "C": (38, 145, 98),
    "D": (122, 31, 140),
}
BLACK = (30, 30, 30)
MID = (95, 95, 95)
GRID = (222, 222, 222)
RED = (150, 25, 25)
WHITE = (255, 255, 255)


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    return ImageFont.truetype(str(FONT_BOLD if bold else FONT), size)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        return
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


class Panel:
    def __init__(self, draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int],
                 xlim: tuple[float, float], ylim: tuple[float, float]):
        self.draw = draw
        self.left, self.top, self.right, self.bottom = box
        self.xlim, self.ylim = xlim, ylim

    def xy(self, x: float, y: float) -> tuple[float, float]:
        px = self.left + (x - self.xlim[0]) / (self.xlim[1] - self.xlim[0]) * (self.right - self.left)
        py = self.bottom - (y - self.ylim[0]) / (self.ylim[1] - self.ylim[0]) * (self.bottom - self.top)
        return px, py

    def axes(self, xticks: list[float], yticks: list[float], xlabel: str = "", ylabel: str = "",
             xlabels: list[str] | None = None, grid: bool = True) -> None:
        if grid:
            for y in yticks:
                _, py = self.xy(self.xlim[0], y)
                self.draw.line((self.left, py, self.right, py), fill=GRID, width=2)
        self.draw.rectangle((self.left, self.top, self.right, self.bottom), outline=BLACK, width=3)
        for i, x in enumerate(xticks):
            px, _ = self.xy(x, self.ylim[0])
            self.draw.line((px, self.bottom, px, self.bottom + 9), fill=BLACK, width=3)
            label = xlabels[i] if xlabels else f"{x:g}"
            self.draw.text((px, self.bottom + 13), label, font=font(22), fill=BLACK, anchor="ma")
        for y in yticks:
            _, py = self.xy(self.xlim[0], y)
            self.draw.line((self.left - 9, py, self.left, py), fill=BLACK, width=3)
            self.draw.text((self.left - 14, py), f"{y:g}", font=font(22), fill=BLACK, anchor="rm")
        if xlabel:
            self.draw.text(((self.left + self.right) / 2, self.bottom + 57), xlabel,
                           font=font(25), fill=BLACK, anchor="ma")
        if ylabel:
            bbox = self.draw.textbbox((0, 0), ylabel, font=font(25))
            text_im = Image.new("RGBA", (bbox[2] + 12, bbox[3] + 12), (255, 255, 255, 0))
            ImageDraw.Draw(text_im).text((6, 6), ylabel, font=font(25), fill=BLACK)
            text_im = text_im.rotate(90, expand=True)
            self.draw._image.paste(text_im, (self.left - 104, int((self.top + self.bottom - text_im.height) / 2)), text_im)

    def line(self, x: np.ndarray, y: np.ndarray, color: tuple[int, int, int], width: int = 5) -> None:
        points = [self.xy(float(xi), float(yi)) for xi, yi in zip(x, y) if np.isfinite(xi) and np.isfinite(yi)]
        if len(points) > 1:
            self.draw.line(points, fill=color, width=width, joint="curve")

    def band(self, image: Image.Image, x: np.ndarray, low: np.ndarray, high: np.ndarray,
             color: tuple[int, int, int], opacity: int = 46) -> None:
        upper = [self.xy(float(xi), float(yi)) for xi, yi in zip(x, high) if np.isfinite(yi)]
        lower = [self.xy(float(xi), float(yi)) for xi, yi in zip(x[::-1], low[::-1]) if np.isfinite(yi)]
        overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
        if len(upper) + len(lower) > 2:
            ImageDraw.Draw(overlay).polygon(upper + lower, fill=(*color, opacity))
        image.alpha_composite(overlay)


def panel_title(draw: ImageDraw.ImageDraw, panel: Panel, label: str, title: str) -> None:
    draw.text((panel.left, panel.top - 42), label, font=font(29, True), fill=BLACK, anchor="ls")
    draw.text((panel.left + 40, panel.top - 42), title, font=font(25, True), fill=BLACK, anchor="ls")


def legend(draw: ImageDraw.ImageDraw, entries: list[tuple[str, tuple[int, int, int]]], x: int, y: int) -> None:
    for i, (label, color) in enumerate(entries):
        yy = y + i * 31
        draw.line((x, yy, x + 43, yy), fill=color, width=6)
        draw.text((x + 54, yy), label, font=font(20), fill=BLACK, anchor="lm")


def load_profile_arrays() -> tuple[np.ndarray, dict[str, dict[tuple[int, int], np.ndarray]]]:
    metrics = read_csv(RESULTS / "hole_all_model_metrics.csv")
    rank_tag = {
        (row["group"], int(row["rank"])): (int(row["prediction_model_no"]), int(row["prediction_seed_no"]))
        for row in metrics
    }
    data: dict[str, dict[tuple[int, int], list[tuple[float, float]]]] = {group: {} for group in "ABCD"}
    for path in (AB_RESULTS / "hole_profiles_interpolated.csv", RESULTS / "hole_CD_profiles_interpolated.csv"):
        for row in read_csv(path):
            group = row["group"]
            row_tag = rank_tag[(group, int(row["rank"]))]
            data[group].setdefault(row_tag, []).append((float(row["z_A"]), float(row["radius_A"])))
    profiles: dict[str, dict[tuple[int, int], np.ndarray]] = {group: {} for group in "ABCD"}
    z_grid = None
    for group in "ABCD":
        for row_tag, values in data[group].items():
            array = np.array(sorted(values), dtype=float)
            profiles[group][row_tag] = array[:, 1]
            if z_grid is None:
                z_grid = array[:, 0]
    assert z_grid is not None
    return z_grid, profiles


def create_window_summaries(z: np.ndarray, profiles: dict[str, dict[tuple[int, int], np.ndarray]]) -> None:
    windows = (
        ("S6_window_mean", -4.0, 6.0),
        ("intracellular_S6_mean", -3.0, 0.0),
        ("gate_to_cavity_mean", 0.0, 6.0),
        ("central_cavity_mean", 6.0, 15.0),
        ("SF_region_mean", 15.0, 22.0),
        ("whole_pore_mean", -4.0, 22.0),
    )
    rng = np.random.default_rng(20260911)
    rows = []
    values_rows = []
    for first, second in (("A", "C"), ("B", "D")):
        tags = sorted(profiles[first])
        for name, low, high in windows:
            mask = (z >= low) & (z <= high)
            first_values = np.array([np.nanmean(profiles[first][row_tag][mask]) for row_tag in tags])
            second_values = np.array([np.nanmean(profiles[second][row_tag][mask]) for row_tag in tags])
            diff = second_values - first_values
            idx = rng.integers(0, len(diff), size=(20000, len(diff)))
            boot = diff[idx].mean(axis=1)
            rows.append({
                "comparison": f"{first}_vs_{second}",
                "window": name,
                "z_low_A": low,
                "z_high_A": high,
                "n_pairs": len(diff),
                "first_group": first,
                "second_group": second,
                "first_mean_radius_A": float(np.mean(first_values)),
                "second_mean_radius_A": float(np.mean(second_values)),
                "paired_mean_difference_A": float(np.mean(diff)),
                "paired_median_difference_A": float(np.median(diff)),
                "paired_bootstrap_CI95_low_A": float(np.percentile(boot, 2.5)),
                "paired_bootstrap_CI95_high_A": float(np.percentile(boot, 97.5)),
                "n_second_wider": int(np.sum(diff > 0)),
                "n_second_narrower": int(np.sum(diff < 0)),
            })
            for row_tag, av, bv, dv in zip(tags, first_values, second_values, diff):
                values_rows.append({
                    "comparison": f"{first}_vs_{second}",
                    "window": name,
                    "prediction_model_no": row_tag[0],
                    "prediction_seed_no": row_tag[1],
                    "first_value_A": float(av),
                    "second_value_A": float(bv),
                    "paired_difference_A": float(dv),
                })
    write_csv(RESULTS / "hole_paired_axial_window_comparisons.csv", rows)
    write_csv(RESULTS / "hole_paired_axial_window_values.csv", values_rows)


def create_prediction_confidence_summary() -> None:
    log_paths = {
        "A": Path("/Users/itoyuto/Downloads/biomolecule/8WE6_1/log.txt"),
        "B": Path("/Users/itoyuto/Downloads/biomolecule/8WE6_1_P55042/log.txt"),
        "C": Path("/Users/itoyuto/Downloads/biomolecule/8WE6_1_wo_DCRD/log.txt"),
        "D": Path("/Users/itoyuto/Downloads/biomolecule/8WE6_1_P55042_no_tmp/log.txt"),
    }
    pattern = re.compile(
        r"model_(\d+)_seed_(\d+) recycle=3 pLDDT=([\d.]+) pTM=([\d.]+)(?: ipTM=([\d.]+))?"
    )
    rows = []
    by_group: dict[str, dict[tuple[int, int], dict]] = {}
    for group, path in log_paths.items():
        group_rows = {}
        for line in path.read_text().splitlines():
            match = pattern.search(line)
            if not match:
                continue
            row = {
                "group": group,
                "prediction_model_no": int(match.group(1)),
                "prediction_seed_no": int(match.group(2)),
                "pLDDT": float(match.group(3)),
                "pTM": float(match.group(4)),
                "ipTM": float(match.group(5)) if match.group(5) else math.nan,
            }
            group_rows[(row["prediction_model_no"], row["prediction_seed_no"])] = row
        by_group[group] = group_rows
        rows.extend(group_rows.values())
    write_csv(RESULTS / "alphafold_prediction_confidence.csv", rows)

    summary_rows = []
    for group in "ABCD":
        for metric in ("pLDDT", "pTM", "ipTM"):
            values = np.array([row[metric] for row in by_group[group].values()], dtype=float)
            values = values[np.isfinite(values)]
            if len(values):
                summary_rows.append({
                    "group": group,
                    "metric": metric,
                    "n": len(values),
                    "mean": float(np.mean(values)),
                    "sd": float(np.std(values, ddof=1)),
                    "median": float(np.median(values)),
                    "min": float(np.min(values)),
                    "max": float(np.max(values)),
                })
    write_csv(RESULTS / "alphafold_prediction_confidence_summary.csv", summary_rows)


def figure_profiles(z: np.ndarray) -> None:
    all_rows = read_csv(RESULTS / "hole_all_profile_summary.csv")
    paired_rows = read_csv(RESULTS / "hole_paired_profile_comparisons.csv")
    x = np.array([float(row["z_A"]) for row in all_rows])
    values = {key: np.array([float(row[key]) for row in all_rows]) for key in all_rows[0] if key != "z_A"}

    im = Image.new("RGBA", (2500, 1880), "white")
    draw = ImageDraw.Draw(im)
    draw.text((115, 55), "Matched HOLE pore-radius comparisons: DCRD deletion and template omission",
              font=font(39, True), fill=BLACK)
    specs = [
        ("A", "C", "A", "A vs C: DCRD present vs absent", (175, 190, 1165, 800), (175, 1080, 1165, 1680), (-0.35, 0.25)),
        ("B", "D", "B", "B vs D: template vs no template", (1415, 190, 2405, 800), (1415, 1080, 2405, 1680), (-0.85, 0.60)),
    ]
    for first, second, label, name, top_box, bottom_box, diff_ylim in specs:
        plot_mask = (x >= -4) & (x <= 24)
        plot_x = x[plot_mask]
        top = Panel(draw, top_box, (-4, 24), (0, 6.2))
        top.band(im, plot_x, values[f"{first}_q10"][plot_mask], values[f"{first}_q90"][plot_mask], COLORS[first], 40)
        top.band(im, plot_x, values[f"{second}_q10"][plot_mask], values[f"{second}_q90"][plot_mask], COLORS[second], 40)
        top.axes([-4, 0, 4, 8, 12, 16, 20, 24], [0, 1, 2, 3, 4, 5, 6], ylabel="HOLE radius (Å)")
        top.line(plot_x, values[f"{first}_median"][plot_mask], COLORS[first], 7)
        top.line(plot_x, values[f"{second}_median"][plot_mask], COLORS[second], 7)
        _, threshold_y = top.xy(-4, 1.15)
        for xx in range(top.left, top.right, 18):
            draw.line((xx, threshold_y, min(xx + 10, top.right), threshold_y), fill=RED, width=3)
        for z0 in (0.0, 19.8):
            px, _ = top.xy(z0, 0)
            for yy in range(top.top, top.bottom, 18):
                draw.line((px, yy, px, min(yy + 9, top.bottom)), fill=MID, width=2)
        draw.text(top.xy(0.35, 5.88), "S6 gate", font=font(20), fill=MID, anchor="la")
        draw.text(top.xy(19.45, 5.88), "SF", font=font(20), fill=MID, anchor="ra")
        panel_title(draw, top, label, name + " (median, 10–90%)")
        legend(draw, [(first, COLORS[first]), (second, COLORS[second])], top.right - 160, top.top + 42)

        comparison = f"{first}_vs_{second}"
        pair = [row for row in paired_rows if row["comparison"] == comparison]
        px = np.array([float(row["z_A"]) for row in pair])
        mean = np.array([float(row["mean_difference_A"]) for row in pair])
        low = np.array([float(row["bootstrap_CI95_low_A"]) for row in pair])
        high = np.array([float(row["bootstrap_CI95_high_A"]) for row in pair])
        pair_mask = (px >= -4) & (px <= 24)
        px, mean, low, high = px[pair_mask], mean[pair_mask], low[pair_mask], high[pair_mask]
        bottom = Panel(draw, bottom_box, (-4, 24), diff_ylim)
        ticks = np.linspace(diff_ylim[0], diff_ylim[1], 6)
        bottom.band(im, px, low, high, COLORS[second], 52)
        bottom.axes([-4, 0, 4, 8, 12, 16, 20, 24], [round(float(v), 2) for v in ticks],
                    xlabel="Axial position from S6 gate toward extracellular side, z (Å)",
                    ylabel=f"Δ radius, {second} − {first} (Å)")
        bottom.line(px, mean, COLORS[second], 7)
        _, zero_y = bottom.xy(-4, 0)
        draw.line((bottom.left, zero_y, bottom.right, zero_y), fill=BLACK, width=3)
        for z0 in (0.0, 19.8):
            x0, _ = bottom.xy(z0, 0)
            for yy in range(bottom.top, bottom.bottom, 18):
                draw.line((x0, yy, x0, min(yy + 9, bottom.bottom)), fill=MID, width=2)
        panel_title(draw, bottom, chr(ord(label) + 2), f"Paired mean difference {second} − {first} (95% bootstrap CI)")
    draw.text((1250, 1833), "HOLE radius is the radius of the largest non-overlapping probe sphere; diameter = 2 × radius.",
              font=font(21), fill=MID, anchor="ma")
    im.convert("RGB").save(RESULTS / "figure_1_HOLE_AC_BD_profile_comparison.png", dpi=(300, 300))


def padded_limits(values: np.ndarray, minimum_span: float = 0.4) -> tuple[float, float]:
    lo, hi = float(np.nanmin(values)), float(np.nanmax(values))
    span = max(hi - lo, minimum_span)
    return lo - 0.12 * span, hi + 0.12 * span


def figure_paired_metrics() -> None:
    point_rows = read_csv(RESULTS / "hole_paired_model_seed_values.csv")
    comp_rows = read_csv(RESULTS / "hole_paired_metric_comparisons.csv")
    im = Image.new("RGBA", (2500, 1870), "white")
    draw = ImageDraw.Draw(im)
    draw.text((115, 55), "Matched model/seed differences at the S6 gate",
              font=font(40, True), fill=BLACK)
    specs = [
        ("A_vs_C", "S6_min_radius_A", "A", "A vs C: S6-window minimum", (185, 200, 1135, 790)),
        ("B_vs_D", "S6_min_radius_A", "B", "B vs D: S6-window minimum", (1435, 200, 2385, 790)),
        ("A_vs_C", "gate_radius_A", "C", "A vs C: radius exactly at z = 0", (185, 1080, 1135, 1670)),
        ("B_vs_D", "gate_radius_A", "D", "B vs D: radius exactly at z = 0", (1435, 1080, 2385, 1670)),
    ]
    for comparison, metric, label, name, box in specs:
        rows = [row for row in point_rows if row["comparison"] == comparison and row["metric"] == metric]
        summary = next(row for row in comp_rows if row["comparison"] == comparison and row["metric"] == metric)
        second = summary["second_group"]
        values = np.array([float(row["paired_difference"]) for row in rows])
        ylim = padded_limits(np.r_[values, 0.0])
        panel = Panel(draw, box, (0.55, 5.45), ylim)
        yticks = list(np.linspace(ylim[0], ylim[1], 6))
        panel.axes([1, 2, 3, 4, 5], [round(float(v), 2) for v in yticks],
                   xlabel="AlphaFold prediction-network model number",
                   ylabel=f"Paired Δ radius, {second} − {summary['first_group']} (Å)")
        _, zero_y = panel.xy(0.55, 0)
        draw.line((panel.left, zero_y, panel.right, zero_y), fill=BLACK, width=3)
        for network in range(1, 6):
            subset = [row for row in rows if int(row["prediction_model_no"]) == network]
            subset.sort(key=lambda row: int(row["prediction_seed_no"]))
            network_values = np.array([float(row["paired_difference"]) for row in subset])
            for row, value in zip(subset, network_values):
                seed = int(row["prediction_seed_no"])
                jitter = (seed - 5.5) * 0.027
                x, y = panel.xy(network + jitter, value)
                draw.ellipse((x - 7, y - 7, x + 7, y + 7), fill=(*COLORS[second], 165))
            mean = float(np.mean(network_values))
            sd = float(np.std(network_values, ddof=1))
            x, y = panel.xy(network, mean)
            _, y0 = panel.xy(network, mean - sd)
            _, y1 = panel.xy(network, mean + sd)
            draw.line((x, y0, x, y1), fill=BLACK, width=3)
            draw.line((x - 14, y, x + 14, y), fill=BLACK, width=6)
        panel_title(draw, panel, label, name)
        annotation = (
            f"overall mean Δ = {float(summary['paired_mean_difference']):+.3f} Å\n"
            f"95% CI {float(summary['paired_bootstrap_CI95_low']):+.3f} to "
            f"{float(summary['paired_bootstrap_CI95_high']):+.3f} Å; "
            f"{summary['n_second_wider']}/50 wider"
        )
        draw.multiline_text((panel.left + 17, panel.top + 16), annotation,
                            font=font(19), fill=BLACK, spacing=4)
    draw.text((1250, 1825), "Dots: individual matched model/seed pairs. Horizontal bars: network-model mean; vertical bars: ±1 SD.",
              font=font(21), fill=MID, anchor="ma")
    im.convert("RGB").save(RESULTS / "figure_2_HOLE_AC_BD_paired_S6_metrics.png", dpi=(300, 300))


def diff_color(value: float, limit: float = 1.0) -> tuple[int, int, int]:
    value = float(np.clip(value / limit, -1.0, 1.0))
    if value < 0:
        t = value + 1.0
        return tuple(int(round(a + t * (b - a))) for a, b in zip((45, 70, 150), (246, 246, 246)))
    return tuple(int(round(a + value * (b - a))) for a, b in zip((246, 246, 246), (177, 45, 55)))


def figure_difference_heatmaps(z: np.ndarray, profiles: dict[str, dict[tuple[int, int], np.ndarray]]) -> None:
    im = Image.new("RGBA", (2500, 1580), "white")
    draw = ImageDraw.Draw(im)
    draw.text((115, 55), "Per-model changes in the complete pore-radius profile",
              font=font(40, True), fill=BLACK)
    specs = [
        ("A", "C", "A", "C − A: effect of DCRD deletion", (195, 215, 1135, 1390)),
        ("B", "D", "B", "D − B: effect of template omission", (1410, 215, 2350, 1390)),
    ]
    tags = sorted(profiles["A"])
    x_mask = (z >= -4) & (z <= 24)
    x_vals = z[x_mask]
    for first, second, label, name, box in specs:
        panel = Panel(draw, box, (-4, 24), (50.5, 0.5))
        diff = np.vstack([profiles[second][row_tag] - profiles[first][row_tag] for row_tag in tags])[:, x_mask]
        width = panel.right - panel.left
        height = panel.bottom - panel.top
        heat = Image.new("RGB", (len(x_vals), 50))
        pix = heat.load()
        for yi in range(50):
            for xi in range(len(x_vals)):
                pix[xi, yi] = diff_color(diff[yi, xi], 1.0)
        heat = heat.resize((width, height), Image.Resampling.NEAREST)
        im.paste(heat, (panel.left, panel.top))
        panel.axes([-4, 0, 4, 8, 12, 16, 20, 24], [5.5, 15.5, 25.5, 35.5, 45.5],
                   xlabel="Axial position from S6 gate, z (Å)",
                   ylabel="Models (network / seed order)", grid=False)
        for y, network in zip((5.5, 15.5, 25.5, 35.5, 45.5), range(1, 6)):
            _, py = panel.xy(-4, y)
            draw.rectangle((panel.left - 98, py - 16, panel.left - 12, py + 16), fill=WHITE)
            draw.text((panel.left - 15, py), f"model {network}", font=font(20), fill=BLACK, anchor="rm")
        for y in (10.5, 20.5, 30.5, 40.5):
            _, py = panel.xy(-4, y)
            draw.line((panel.left, py, panel.right, py), fill=WHITE, width=3)
        for z0 in (0.0, 19.8):
            px, _ = panel.xy(z0, 1)
            draw.line((px, panel.top, px, panel.bottom), fill=BLACK, width=3)
        panel_title(draw, panel, label, name)

    bar_left, bar_right, bar_top, bar_bottom = 1188, 1242, 330, 1235
    for y in range(bar_top, bar_bottom):
        value = 1.0 - 2.0 * (y - bar_top) / (bar_bottom - bar_top)
        draw.line((bar_left, y, bar_right, y), fill=diff_color(value), width=1)
    draw.rectangle((bar_left, bar_top, bar_right, bar_bottom), outline=BLACK, width=3)
    for value in (-1.0, -0.5, 0.0, 0.5, 1.0):
        y = bar_top + (1.0 - value) / 2.0 * (bar_bottom - bar_top)
        draw.line((bar_right, y, bar_right + 9, y), fill=BLACK, width=3)
        draw.text((bar_right + 15, y), f"{value:+.1f}", font=font(19), fill=BLACK, anchor="lm")
    draw.text((1215, 278), "Paired Δ radius\n(Å)", font=font(21, True), fill=BLACK, anchor="ma", spacing=3)
    draw.text((1250, 1515), "Blue: second structure is narrower; red: second structure is wider. Rows are model 1–5, then seed 1–10.",
              font=font(21), fill=MID, anchor="ma")
    im.convert("RGB").save(RESULTS / "figure_3_HOLE_AC_BD_difference_heatmaps.png", dpi=(300, 300))


def radius_color(value: float) -> tuple[int, int, int]:
    stops = [
        (0.0, (106, 4, 15)), (1.15, (249, 65, 68)), (1.5, (249, 199, 79)),
        (2.3, (67, 170, 139)), (4.0, (39, 125, 161)), (6.0, (20, 33, 61)),
    ]
    value = float(np.clip(value, stops[0][0], stops[-1][0]))
    for (x0, c0), (x1, c1) in zip(stops, stops[1:]):
        if value <= x1:
            t = (value - x0) / (x1 - x0)
            return tuple(int(round(a + t * (b - a))) for a, b in zip(c0, c1))
    return stops[-1][1]


def figure_all_heatmaps(z: np.ndarray, profiles: dict[str, dict[tuple[int, int], np.ndarray]]) -> None:
    im = Image.new("RGBA", (2500, 1900), "white")
    draw = ImageDraw.Draw(im)
    draw.text((115, 55), "All 200 HOLE pore-radius profiles in matched model/seed order",
              font=font(40, True), fill=BLACK)
    boxes = {
        "A": (185, 210, 1110, 880), "C": (1390, 210, 2315, 880),
        "B": (185, 1110, 1110, 1780), "D": (1390, 1110, 2315, 1780),
    }
    titles = {
        "A": "A: DCRD present", "C": "C: DCRD absent",
        "B": "B: template", "D": "D: no template",
    }
    tags = sorted(profiles["A"])
    mask = (z >= -4) & (z <= 24)
    xv = z[mask]
    for idx, group in enumerate("ACBD"):
        panel = Panel(draw, boxes[group], (-4, 24), (50.5, 0.5))
        values = np.vstack([profiles[group][row_tag] for row_tag in tags])[:, mask]
        heat = Image.new("RGB", (len(xv), 50))
        pix = heat.load()
        for yi in range(50):
            for xi in range(len(xv)):
                pix[xi, yi] = radius_color(values[yi, xi])
        heat = heat.resize((panel.right - panel.left, panel.bottom - panel.top), Image.Resampling.NEAREST)
        im.paste(heat, (panel.left, panel.top))
        panel.axes([-4, 0, 4, 8, 12, 16, 20, 24], [5.5, 15.5, 25.5, 35.5, 45.5],
                   xlabel="Axial position, z (Å)", ylabel="Models (network / seed)", grid=False)
        for y, network in zip((5.5, 15.5, 25.5, 35.5, 45.5), range(1, 6)):
            _, py = panel.xy(-4, y)
            draw.rectangle((panel.left - 95, py - 15, panel.left - 12, py + 15), fill=WHITE)
            draw.text((panel.left - 15, py), f"model {network}", font=font(19), fill=BLACK, anchor="rm")
        for y in (10.5, 20.5, 30.5, 40.5):
            _, py = panel.xy(-4, y)
            draw.line((panel.left, py, panel.right, py), fill=WHITE, width=3)
        for z0 in (0.0, 19.8):
            px, _ = panel.xy(z0, 1)
            draw.line((px, panel.top, px, panel.bottom), fill=WHITE, width=3)
        panel_title(draw, panel, chr(ord("A") + idx), titles[group])
    # Compact shared color bar between the column pairs.
    left, right, top, bottom = 1198, 1247, 445, 1545
    for y in range(top, bottom):
        value = 6.0 * (bottom - y) / (bottom - top)
        draw.line((left, y, right, y), fill=radius_color(value), width=1)
    draw.rectangle((left, top, right, bottom), outline=BLACK, width=3)
    for value in (0, 1.15, 2.3, 4, 6):
        y = bottom - value / 6.0 * (bottom - top)
        draw.line((right, y, right + 9, y), fill=BLACK, width=3)
        draw.text((right + 14, y), f"{value:g}", font=font(19), fill=BLACK, anchor="lm")
    draw.text((1223, 394), "HOLE radius\n(Å)", font=font(21, True), fill=BLACK, anchor="ma", spacing=3)
    im.convert("RGB").save(RESULTS / "figure_4_HOLE_AC_BD_all_profile_heatmaps.png", dpi=(300, 300))


def main() -> None:
    z, profiles = load_profile_arrays()
    create_window_summaries(z, profiles)
    create_prediction_confidence_summary()
    figure_profiles(z)
    figure_paired_metrics()
    figure_difference_heatmaps(z, profiles)
    figure_all_heatmaps(z, profiles)
    print(f"Wrote comparison figures and secondary summaries to {RESULTS}")


if __name__ == "__main__":
    main()
