#!/usr/bin/env python3
"""Reproduce the original four-panel bottleneck figure for A-C and B-D."""

from __future__ import annotations

import csv
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw

from make_comparison_figures import BLACK, GRID, Panel, COLORS, font, panel_title


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"


def read_csv(name: str) -> list[dict[str, str]]:
    with (RESULTS / name).open(newline="") as handle:
        return list(csv.DictReader(handle))


METRICS = read_csv("hole_all_model_metrics.csv")
SUMMARIES = read_csv("hole_all_metric_summaries.csv")
BY_NETWORK = read_csv("hole_all_by_prediction_model.csv")
PAIRED = read_csv("hole_paired_metric_comparisons.csv")


def values(metric: str, group: str) -> np.ndarray:
    return np.array([float(row[metric]) for row in METRICS if row["group"] == group])


def summary(metric: str, group: str) -> dict[str, str]:
    return next(row for row in SUMMARIES if row["metric"] == metric and row["group"] == group)


def paired_summary(metric: str, first: str, second: str) -> dict[str, str]:
    return next(
        row for row in PAIRED
        if row["metric"] == metric and row["comparison"] == f"{first}_vs_{second}"
    )


def draw_distribution(
    image: Image.Image,
    draw: ImageDraw.ImageDraw,
    panel: Panel,
    metric: str,
    first: str,
    second: str,
    ylabel: str,
    label: str,
    title: str,
    annotation: str | None = None,
) -> None:
    panel.axes([1, 2], list(np.arange(panel.ylim[0], panel.ylim[1] + 1e-6, 0.5)),
               ylabel=ylabel, xlabels=[first, second])
    rng = np.random.default_rng(20260906 + ord(label) + ord(first) + ord(second))
    for group_x, group in ((1, first), (2, second)):
        group_values = values(metric, group)
        jitter = rng.uniform(-0.14, 0.14, len(group_values))
        for x_value, y_value in zip(group_x + jitter, group_values):
            x, y = panel.xy(float(x_value), float(y_value))
            draw.ellipse((x - 6, y - 6, x + 6, y + 6), fill=(*COLORS[group], 190))
        stats = summary(metric, group)
        x, _ = panel.xy(group_x, 0)
        _, y05 = panel.xy(group_x, float(stats["q05"]))
        _, y95 = panel.xy(group_x, float(stats["q95"]))
        _, y25 = panel.xy(group_x, float(stats["q25"]))
        _, y75 = panel.xy(group_x, float(stats["q75"]))
        _, y50 = panel.xy(group_x, float(stats["median"]))
        draw.line((x, y05, x, y95), fill=BLACK, width=4)
        draw.line((x - 15, y05, x + 15, y05), fill=BLACK, width=4)
        draw.line((x - 15, y95, x + 15, y95), fill=BLACK, width=4)
        draw.rectangle((x - 50, y75, x + 50, y25), fill=(255, 255, 255, 220), outline=BLACK, width=4)
        draw.line((x - 50, y50, x + 50, y50), fill=BLACK, width=5)
    panel_title(draw, panel, label, title)
    if annotation:
        draw.multiline_text((panel.left + 18, panel.top + 18), annotation,
                            font=font(21), fill=BLACK, spacing=5)


def comparison_annotation(first: str, second: str) -> str:
    row = paired_summary("S6_min_radius_A", first, second)
    return (
        f"mean: {float(row['first_mean']):.3f} → {float(row['second_mean']):.3f} Å   "
        f"paired Δ = {float(row['paired_mean_difference']):+.3f} Å "
        f"({float(row['percent_change_vs_first_mean']):+.1f}%)\n"
        f"95% paired bootstrap CI: {float(row['paired_bootstrap_CI95_low']):+.3f} "
        f"to {float(row['paired_bootstrap_CI95_high']):+.3f} Å\n"
        f"Cohen dz = {float(row['cohen_dz']):+.2f}; matched r = {float(row['paired_correlation']):.2f}\n"
        f"medians: {float(row['first_median']):.3f} vs {float(row['second_median']):.3f} Å"
    )


def network_panel(draw: ImageDraw.ImageDraw, panel: Panel, first: str, second: str) -> None:
    panel.axes([1, 2, 3, 4, 5], [0, 0.5, 1, 1.5, 2],
               xlabel="AlphaFold prediction-network model number",
               ylabel="S6 minimum radius (Å)")
    panel_title(draw, panel, "D", "S6 minimum radius by prediction-network model")
    for group, offset in ((first, -0.07), (second, 0.07)):
        rows = sorted(
            [
                row for row in BY_NETWORK
                if row["metric"] == "S6_min_radius_A" and row["group"] == group
            ],
            key=lambda row: int(row["prediction_model_no"]),
        )
        points = []
        for row in rows:
            x_value = int(row["prediction_model_no"]) + offset
            mean = float(row["mean"])
            sd = float(row["sd"])
            x, y = panel.xy(x_value, mean)
            _, y0 = panel.xy(x_value, mean - sd)
            _, y1 = panel.xy(x_value, mean + sd)
            draw.line((x, y0, x, y1), fill=COLORS[group], width=4)
            draw.line((x - 12, y0, x + 12, y0), fill=COLORS[group], width=4)
            draw.line((x - 12, y1, x + 12, y1), fill=COLORS[group], width=4)
            draw.ellipse((x - 8, y - 8, x + 8, y + 8), fill=COLORS[group])
            points.append((x, y))
        draw.line(points, fill=COLORS[group], width=5)

    legend_x, legend_y = panel.right - 430, panel.top + 55
    for index, group in enumerate((first, second)):
        y = legend_y + index * 35
        draw.line((legend_x, y, legend_x + 55, y), fill=COLORS[group], width=6)
        draw.text((legend_x + 70, y), f"{group} mean ± SD", font=font(22), fill=BLACK, anchor="lm")


def make_figure(first: str, second: str, filename: str, condition: str) -> None:
    image = Image.new("RGBA", (2400, 1850), "white")
    draw = ImageDraw.Draw(image)
    draw.text((120, 55),
              f"HOLE bottleneck geometry and prediction-model dependence: {first} vs {second}",
              font=font(40, True), fill=BLACK)
    draw.text((2280, 62), condition, font=font(22), fill=(90, 90, 90), anchor="ra")

    panels = [
        Panel(draw, (190, 185, 1110, 820), (0.55, 2.45), (0, 2.5)),
        Panel(draw, (1380, 185, 2300, 820), (0.55, 2.45), (0, 2.65)),
        Panel(draw, (190, 1065, 1110, 1700), (0.55, 2.45), (0, 2.25)),
        Panel(draw, (1380, 1065, 2300, 1700), (0.6, 5.4), (0, 2.4)),
    ]

    draw_distribution(
        image, draw, panels[0], "S6_min_radius_A", first, second, "Radius (Å)", "A",
        "S6-window minimum radius (−4 ≤ z ≤ 6 Å)",
        comparison_annotation(first, second),
    )
    draw_distribution(
        image, draw, panels[1], "gate_radius_A", first, second, "Radius (Å)", "B",
        "Radius at S6 gate landmark (z = 0)",
    )
    draw_distribution(
        image, draw, panels[2], "SF_min_radius_A", first, second, "Radius (Å)", "C",
        "Selectivity-filter-window minimum radius",
    )
    network_panel(draw, panels[3], first, second)
    image.convert("RGB").save(RESULTS / filename, dpi=(300, 300))


def main() -> None:
    make_figure(
        "A", "C", "figure_6_HOLE_A_vs_C_bottleneck_metrics.png",
        "DCRD present vs absent",
    )
    make_figure(
        "B", "D", "figure_7_HOLE_B_vs_D_bottleneck_metrics.png",
        "Rad present: template vs no template",
    )
    print("Wrote A-C and B-D four-panel bottleneck figures")


if __name__ == "__main__":
    main()
