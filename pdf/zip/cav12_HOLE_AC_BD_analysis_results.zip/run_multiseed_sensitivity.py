#!/usr/bin/env python3
"""Three-seed HOLE sensitivity analysis for all 200 A/B/C/D structures."""

from __future__ import annotations

import argparse
import csv
import math
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import numpy as np


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
PREVIOUS_ROOT = ROOT.parent / "cav12_hole_analysis"
sys.path.insert(0, str(PREVIOUS_ROOT))
import run_hole_analysis as base  # noqa: E402


METRIC_NAMES = (
    "S6_min_radius_A", "gate_radius_A", "SF_min_radius_A",
    "SF_landmark_radius_A", "pore_min_radius_A", "S6_min_z_A", "pore_min_z_A",
)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def metric_from_profile(profile: np.ndarray, sf_z: float) -> dict[str, float]:
    s6, s6_z = base.interval_min(base.PROFILE_GRID, profile, -4.0, 6.0)
    sf, sf_min_z = base.interval_min(base.PROFILE_GRID, profile, sf_z - 3.0, sf_z + 3.0)
    pore, pore_z = base.interval_min(base.PROFILE_GRID, profile, -4.0, sf_z + 3.0)
    return {
        "S6_min_radius_A": s6,
        "gate_radius_A": float(np.interp(0.0, base.PROFILE_GRID, profile)),
        "SF_min_radius_A": sf,
        "SF_landmark_radius_A": float(np.interp(sf_z, base.PROFILE_GRID, profile)),
        "pore_min_radius_A": pore,
        "S6_min_z_A": s6_z,
        "pore_min_z_A": pore_z,
    }


def paired_ci(diff: np.ndarray, rng: np.random.Generator) -> tuple[float, float]:
    idx = rng.integers(0, len(diff), size=(20000, len(diff)))
    means = diff[idx].mean(axis=1)
    return float(np.percentile(means, 2.5)), float(np.percentile(means, 97.5))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--workers", type=int, default=8)
    args = parser.parse_args()

    all_metrics = read_csv(RESULTS / "hole_all_model_metrics.csv")
    source_rows = {
        (row["group"], int(row["prediction_model_no"]), int(row["prediction_seed_no"])): row
        for row in all_metrics
    }
    base.RUNS = RESULTS / "hole_multiseed_runs"
    base.RUNS.mkdir(parents=True, exist_ok=True)

    jobs = []
    for group in "ABCD":
        comparison_offset = 0 if group in "AC" else 100000
        for model_no in range(1, 6):
            for prediction_seed in range(1, 11):
                row = source_rows[(group, model_no, prediction_seed)]
                for replicate in range(1, 4):
                    hole_seed = 520000 + comparison_offset + model_no * 1000 + prediction_seed * 10 + replicate
                    model = base.ModelInfo(
                        f"{group}_ms{replicate}", int(row["rank"]), Path(row["source_file"]), hole_seed
                    )
                    jobs.append((group, model_no, prediction_seed, replicate, model))

    outputs = []
    with ThreadPoolExecutor(max_workers=args.workers) as pool:
        futures = {pool.submit(base.run_one, job[-1]): job for job in jobs}
        for future in as_completed(futures):
            outputs.append((*futures[future][:-1], future.result()))
    outputs.sort(key=lambda item: item[:4])

    replicate_rows = []
    buckets: dict[tuple[str, int, int], list[dict]] = {}
    for group, model_no, prediction_seed, replicate, output in outputs:
        item = {
            "group": group,
            "prediction_model_no": model_no,
            "prediction_seed_no": prediction_seed,
            "hole_replicate": replicate,
            **output["metrics"],
        }
        item["group"] = group
        item["rank"] = output["model"].rank
        item["prediction_model_no"] = model_no
        item["prediction_seed_no"] = prediction_seed
        replicate_rows.append(item)
        buckets.setdefault((group, model_no, prediction_seed), []).append(output)
    write_csv(RESULTS / "hole_multiseed_replicate_metrics.csv", replicate_rows)

    aggregate_rows = []
    aggregate_profiles: dict[tuple[str, int, int], np.ndarray] = {}
    for key, bucket in sorted(buckets.items()):
        group, model_no, prediction_seed = key
        profile = np.nanmedian(np.vstack([item["profile"] for item in bucket]), axis=0)
        aggregate_profiles[key] = profile
        sf_z = float(bucket[0]["metrics"]["sf_landmark_z_A"])
        per_rep_s6 = np.array([item["metrics"]["S6_min_radius_A"] for item in bucket])
        per_rep_gate = np.array([item["metrics"]["gate_radius_A"] for item in bucket])
        aggregate_rows.append({
            "group": group,
            "rank": bucket[0]["model"].rank,
            "source_file": str(bucket[0]["model"].source),
            "prediction_model_no": model_no,
            "prediction_seed_no": prediction_seed,
            "n_hole_seeds": 3,
            "sf_landmark_z_A": sf_z,
            **metric_from_profile(profile, sf_z),
            "S6_replicate_median_A": float(np.median(per_rep_s6)),
            "S6_replicate_range_A": float(np.max(per_rep_s6) - np.min(per_rep_s6)),
            "gate_replicate_median_A": float(np.median(per_rep_gate)),
            "gate_replicate_range_A": float(np.max(per_rep_gate) - np.min(per_rep_gate)),
        })
    write_csv(RESULTS / "hole_multiseed_aggregate_model_metrics.csv", aggregate_rows)

    lookup = {
        (row["group"], int(row["prediction_model_no"]), int(row["prediction_seed_no"])): row
        for row in aggregate_rows
    }
    rng = np.random.default_rng(20260915)
    comparison_rows = []
    for first, second in (("A", "C"), ("B", "D")):
        tags = [(model, seed) for model in range(1, 6) for seed in range(1, 11)]
        for metric in METRIC_NAMES:
            a = np.array([float(lookup[(first, *row_tag)][metric]) for row_tag in tags])
            b = np.array([float(lookup[(second, *row_tag)][metric]) for row_tag in tags])
            diff = b - a
            low, high = paired_ci(diff, rng)
            comparison_rows.append({
                "comparison": f"{first}_vs_{second}",
                "metric": metric,
                "n_pairs": len(diff),
                "first_mean": float(np.mean(a)),
                "first_sd": float(np.std(a, ddof=1)),
                "first_median": float(np.median(a)),
                "second_mean": float(np.mean(b)),
                "second_sd": float(np.std(b, ddof=1)),
                "second_median": float(np.median(b)),
                "paired_mean_difference": float(np.mean(diff)),
                "paired_median_difference": float(np.median(diff)),
                "paired_bootstrap_CI95_low": low,
                "paired_bootstrap_CI95_high": high,
                "n_second_wider": int(np.sum(diff > 0)),
                "n_second_narrower": int(np.sum(diff < 0)),
            })
    write_csv(RESULTS / "hole_multiseed_paired_metric_comparisons.csv", comparison_rows)

    variability_rows = []
    for group in "ABCD":
        rows = [row for row in aggregate_rows if row["group"] == group]
        for metric in ("S6_replicate_range_A", "gate_replicate_range_A"):
            values = np.array([float(row[metric]) for row in rows])
            variability_rows.append({
                "group": group,
                "metric": metric,
                "n": len(values),
                "mean": float(np.mean(values)),
                "median": float(np.median(values)),
                "q90": float(np.percentile(values, 90)),
                "max": float(np.max(values)),
            })
    write_csv(RESULTS / "hole_multiseed_path_variability.csv", variability_rows)
    print(f"Wrote three-seed sensitivity analysis to {RESULTS}")


if __name__ == "__main__":
    main()
